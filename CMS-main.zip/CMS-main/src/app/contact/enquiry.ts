export class Enquiry1 {  
    constructor(
        public name:string,
        public email:string,
        public mobile:number=0,
        public gender:string,
        public courses:string,
        public trainingmode:string

    ){}

}